close all;
clear all;

plotSubs = true; % if true it makes subplots, otherwise it animates

if plotSubs
    figure('Position', [0, 0, 600, 1080])
else
    figure('Position', [0, 700, 1400, 300])
end

% trombaString = load ('/Users/SilvinW/repositories/TrombaMarina/Builds/MacOSX/build/Debug/stringState.csv');
% bridge = load ('/Users/SilvinW/repositories/TrombaMarina/Builds/MacOSX/build/Debug/bridgeState.csv');
% body = load ('/Users/SilvinW/repositories/TrombaMarina/Builds/MacOSX/build/Debug/bodyState.csv');
% sampleNumber = load ('/Users/SilvinW/repositories/TrombaMarina/Builds/MacOSX/build/Debug/sampleNumber.csv');

% load matfiles
load trombaString.mat
load bridge.mat
load body.mat
load sampleNumber.mat

N = length(trombaString(1, :));
Ny = size(body, 1) / length(sampleNumber);

% mean value of string state
testMean = mean(mean(((ones(size(trombaString))) * 12 / 17 + (-trombaString + 5e-6) * 100)));

scaling = 100; % scaling for platestate

% use different range if plotSubs == true
if plotSubs
    j = 1;
    range = 17:20:90;
else
    range = 1:size(trombaString, 1)-1;
end

%% loop
for i = range
    %subplots
    if plotSubs
        subplot(4, 1, j)
        j = j + 1;
    end
    
    hold off;
    % surf string using data from tubeplot (needs tubeplot.m)
    [x, y, z] = tubeplot([(1:N) / N; (ones(1, N) * 12 / 17 + (-trombaString(i, :) + 5e-6) * 100) ; ones(1, N) * 5e-6], 8e-3);
    surf(x, y, 0.02*z, (y - testMean) * 0.00001 * scaling + 0.0000005 * scaling);
    
    %colors
    colormap(gray);
    shading interp
    
    hold on;
    
    % surf plate
    idxs = (1:134) / 134 * 1.35 / 1.90;
    idxs = idxs + (1-idxs(end));
    surf(idxs, (1:17) / 17, body(1+i*Ny : (i+1) * Ny, :)*scaling, 'Facealpha', 0.7);
    
    % title
    title(num2str(sampleNumber (i)));

    % plot limits 
    xlim([0, 1])
    ylim([0, 1])
    zlim([-5e-3, 5e-3])
    
    % color
    colormap(gray);
    caxis([-1e-6 1e-6] * scaling)
    shading interp

    % view
    view([6.43279145378544 40.6120183749305])
    
    % extra settings
    axis off;
    set(gca, 'Projection', 'perspective');%, 'Position', [-0.1, -0.1, 1, 1])
    set(gcf, 'color', [0.4, 0.4, 0.4])

    drawnow;
    pause(0.01);
end